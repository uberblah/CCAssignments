a = {0:1, 1:2, 2:3}
b = {3:4, 4:5, 5:6}
c = a or b
print c[0]
print c[1]
print c[2]
