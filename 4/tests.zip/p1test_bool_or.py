print True or False
print True or True
print False or True
print False or False
