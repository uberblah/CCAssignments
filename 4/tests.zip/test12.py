print input() + input()
