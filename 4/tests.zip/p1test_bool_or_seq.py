print True or input()

