a = ((((input() + input()) + (input() + input())) + ((input() + input()) + (input() + input()))) + (((input() + input()) + (input() + input())) + ((input() + input()) + (input() + input()))))
b = ((((input() + input()) + (input() + input())) + ((input() + input()) + (input() + input()))) + (((input() + input()) + (input() + input())) + ((input() + input()) + (input() + input())))) + (a + a)
print  (input() + input()) + (a + b) + (a + b) + (input() + input())
