a = True
b = False
print a and b
print a and a
print b and b
