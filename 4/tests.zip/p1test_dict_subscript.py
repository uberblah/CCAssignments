a = {1:2}
print a[1]
