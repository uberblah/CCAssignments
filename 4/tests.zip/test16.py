a=2+2
2+2+2+input()
print a
a=(2+2+(- 5))+(input()+5+2)
2+2+2+input()
print a
print input() + input()
a = - input()
print a + input()
myface = 4
yourface = myface
theblackholeisa = myface
everything = yourface
myface = everything
print myface

print -input() + input() + -input() + input() + -input() + input() + -input() + input() + -input() + input() + -input() + input() + -input() + input() + -input() + input() + -input() + input() + -input() + input() + -input() + input() + -input() + input() + -input() + input() + -input() + input() + -input() + input() + -input() + input() + -input() + input() + -input() + input() + -input() + input() + -input() + input() + -input() + input() + -input() + input() + -input() + input() + -input() + input() + -input() + input() + -input() + input() + -input() + input() + -input() + input() + -input() + input() + -input() + input() + -input()
print 5
print 7
print input()
print ((((input() + input()) + (input() + input())) + ((input() + input()) + (input() + input()))) + (((input() + input()) + (input() + input())) + ((input() + input()) + (input() + input()))))
a = ((((input() + input()) + (input() + input())) + ((input() + input()) + (input() + input()))) + (((input() + input()) + (input() + input())) + ((input() + input()) + (input() + input()))))
b = ((((input() + input()) + (input() + input())) + ((input() + input()) + (input() + input()))) + (((input() + input()) + (input() + input())) + ((input() + input()) + (input() + input())))) + (a + a)
print  (a + b) + (a + b)
a = ((((input() + input()) + (input() + input())) + ((input() + input()) + (input() + input()))) + (((input() + input()) + (input() + input())) + ((input() + input()) + (input() + input()))))
b = ((((input() + input()) + (input() + input())) + ((input() + input()) + (input() + input()))) + (((input() + input()) + (input() + input())) + ((input() + input()) + (input() + input())))) + (a + a)
print  (input() + input()) + (a + b) + (a + b) + (input() + input())
2+2
a=2+2
