print 1 if input() else 2
print 1 if input() else 2
