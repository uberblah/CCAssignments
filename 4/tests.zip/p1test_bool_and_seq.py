print False and input()
