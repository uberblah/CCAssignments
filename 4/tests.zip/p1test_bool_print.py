print True
print False
print False + False
print True + False
print True + True
print True + 0
