b = {}
c = {input(): 1, 5:input()}

