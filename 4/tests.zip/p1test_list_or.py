a = [1, 2, 3]
b = [4, 5, 6]
c = a or b
print c[0]
print c[1]
print c[2]
