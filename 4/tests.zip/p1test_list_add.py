a = [1, 2, 3]
b = [4, 5, 6]
c = a + b
print c[0]
print c[1]
print c[2]
print c[3]
print c[4]
print c[5]

