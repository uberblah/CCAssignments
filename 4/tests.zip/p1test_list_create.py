i = input()
a = [i, 2, 3, 4, 5]
print i
