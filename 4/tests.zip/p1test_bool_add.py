print False + True
print True + False
print False + False
print True + True
