print ((((input() + input()) + (input() + input())) + ((input() + input()) + (input() + input()))) + (((input() + input()) + (input() + input())) + ((input() + input()) + (input() + input()))))
