print True == False
print True is False
print True != False
print False == True
print False is True
print False != True
print True == True
print True is True
print True != True
print False == False
print False is False
print False != False
print 0 == 1
print 0 is 1
print 0 != 1
print 1 == 0
print 1 is 0
print 1 != 0
print 0 == 0
print 0 is 0
print 0 != 0
print 1 == 1
print 1 is 1
print 1 != 1
a = [1, 2, 3]
b = [1, 2, 3]
c = {1:2, 2:3, 3:4}
d = {1:2, 2:3, 3:4}
e = [0, 1, 2]
f = {4:5, 5:6, 6:7}
print a == a
print a is a
print a != a
print a == b
print a is b
print a != b
print c == c
print c is c
print c != c
print c == d
print c is d
print c != d
print a == e
print a is e
print a != e
print c == f
print c is f
print c != f
print [] == []
print [] is []
print [] != []

