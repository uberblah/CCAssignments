a=2+2
2+2+2+input()
print a
