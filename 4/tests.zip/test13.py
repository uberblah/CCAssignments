a = - input()
print a + input()
