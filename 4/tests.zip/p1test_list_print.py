print []
print [1]
print [1, 2, 3]

