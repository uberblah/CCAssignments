a = 1
b = 2
c = 3
d = 4
e = 5
f = 6
g = 6
h = 7
i = 8
j = 9
print a
