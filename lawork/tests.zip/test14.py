myface = 4
yourface = myface
theblackholeisa = myface
everything = yourface
myface = everything
print myface

