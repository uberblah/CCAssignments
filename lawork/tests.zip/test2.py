print 7
