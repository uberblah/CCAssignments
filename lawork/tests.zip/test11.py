a=(2+2+(- 5))+(input()+5+2)
2+2+2+input()
print a
