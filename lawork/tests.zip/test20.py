a = input()
b = input()
c = input()
d = input()
e = input()
f = input()
g = input()
print a
print b
print c
print d
print e
print f
print g

