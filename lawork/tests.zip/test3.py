print input()
